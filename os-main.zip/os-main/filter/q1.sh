cut -c 5-8 f1
# write a command to cut 5 to 8 characters of the file f1