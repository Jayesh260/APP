grep "^SRM" f1
# a command to display the lines of the file f1 starts with SRM